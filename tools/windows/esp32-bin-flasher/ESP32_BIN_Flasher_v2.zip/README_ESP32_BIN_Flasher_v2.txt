﻿ESP32 BIN Flasher v2

Исправления:
- GUI больше не читает stdout/stderr esptool блокирующим способом.
- Добавлена кнопка STOP.
- Добавлена ПРОВЕРКА СВЯЗИ перед прошивкой.
- Добавлены режимы входа в загрузчик:
  AUTO - DTR/RTS
  MANUAL BOOT - USB/JTAG
  MANUAL BOOT - UART
- Для ручного USB/JTAG ESP32-S3 используется watchdog-reset после операции.

Для ESP32-8048S043:
1. Запустите START_ESP32_BIN_Flasher_v2.cmd.
2. Выберите BIN.
3. Выберите COM.
4. Оставьте chip = esp32s3.
5. Сначала попробуйте AUTO - DTR/RTS и кнопку ПРОВЕРИТЬ СВЯЗЬ.
6. Если AUTO не сработал:
   - зажмите BOOT;
   - нажмите и отпустите RESET/RST/EN;
   - отпустите BOOT;
   - выберите MANUAL BOOT - USB/JTAG;
   - нажмите ПРОВЕРИТЬ СВЯЗЬ;
   - затем ПРОШИТЬ.
7. Для полного образа проекта адрес 0x0.

Пример AUTO:
python -m esptool --chip esp32s3 --port COM12 --baud 921600 --before default-reset --after hard-reset write-flash 0x0 "firmware.bin"

Пример ручного USB/JTAG:
python -m esptool --chip esp32s3 --port COM12 --baud 921600 --before no-reset --after watchdog-reset write-flash 0x0 "firmware.bin"

erase-flash автоматически НЕ выполняется.
