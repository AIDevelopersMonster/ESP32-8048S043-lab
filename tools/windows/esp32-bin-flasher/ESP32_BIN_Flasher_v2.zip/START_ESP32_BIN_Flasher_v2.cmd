@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0ESP32_BIN_Flasher_v2.ps1"
if errorlevel 1 (
  echo.
  echo GUI did not start correctly.
  pause
)
