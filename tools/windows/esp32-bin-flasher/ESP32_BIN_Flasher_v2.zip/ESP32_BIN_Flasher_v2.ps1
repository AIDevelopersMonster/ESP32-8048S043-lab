﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$form = New-Object System.Windows.Forms.Form
$form.Text = "ESP32 BIN Flasher v2"
$form.Size = New-Object System.Drawing.Size(790,650)
$form.StartPosition = "CenterScreen"
$form.Font = New-Object System.Drawing.Font("Segoe UI",10)
$form.MaximizeBox = $false

$script:proc = $null
$script:operation = ""
$script:lastLog = ""
$script:logFile = Join-Path $env:TEMP ("esp32_flasher_{0}.log" -f [System.Diagnostics.Process]::GetCurrentProcess().Id)
$script:cmdFile = Join-Path $env:TEMP ("esp32_flasher_{0}.cmd" -f [System.Diagnostics.Process]::GetCurrentProcess().Id)

function Add-Label($text,$x,$y,$w=0) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $text
    $l.Location = New-Object System.Drawing.Point($x,$y)
    if ($w -gt 0) {
        $l.Size = New-Object System.Drawing.Size($w,24)
    } else {
        $l.AutoSize = $true
    }
    $form.Controls.Add($l)
    return $l
}

Add-Label "BIN файл:" 20 22 | Out-Null
$txtBin = New-Object System.Windows.Forms.TextBox
$txtBin.Location = New-Object System.Drawing.Point(110,18)
$txtBin.Size = New-Object System.Drawing.Size(525,28)
$form.Controls.Add($txtBin)

$btnBrowse = New-Object System.Windows.Forms.Button
$btnBrowse.Text = "Выбрать..."
$btnBrowse.Location = New-Object System.Drawing.Point(645,17)
$btnBrowse.Size = New-Object System.Drawing.Size(105,30)
$form.Controls.Add($btnBrowse)

Add-Label "COM порт:" 20 67 | Out-Null
$cmbPort = New-Object System.Windows.Forms.ComboBox
$cmbPort.Location = New-Object System.Drawing.Point(110,63)
$cmbPort.Size = New-Object System.Drawing.Size(120,28)
$cmbPort.DropDownStyle = "DropDownList"
$form.Controls.Add($cmbPort)

$btnRefresh = New-Object System.Windows.Forms.Button
$btnRefresh.Text = "Обновить"
$btnRefresh.Location = New-Object System.Drawing.Point(240,62)
$btnRefresh.Size = New-Object System.Drawing.Size(95,30)
$form.Controls.Add($btnRefresh)

Add-Label "Чип:" 360 67 | Out-Null
$cmbChip = New-Object System.Windows.Forms.ComboBox
$cmbChip.Location = New-Object System.Drawing.Point(410,63)
$cmbChip.Size = New-Object System.Drawing.Size(115,28)
$cmbChip.DropDownStyle = "DropDownList"
"esp32s3","esp32","esp32c3" | ForEach-Object { [void]$cmbChip.Items.Add($_) }
$cmbChip.SelectedIndex = 0
$form.Controls.Add($cmbChip)

Add-Label "Baud:" 550 67 | Out-Null
$cmbBaud = New-Object System.Windows.Forms.ComboBox
$cmbBaud.Location = New-Object System.Drawing.Point(605,63)
$cmbBaud.Size = New-Object System.Drawing.Size(145,28)
$cmbBaud.DropDownStyle = "DropDownList"
"921600","460800","115200" | ForEach-Object { [void]$cmbBaud.Items.Add($_) }
$cmbBaud.SelectedIndex = 0
$form.Controls.Add($cmbBaud)

Add-Label "Вход в загрузчик:" 20 112 | Out-Null
$cmbBoot = New-Object System.Windows.Forms.ComboBox
$cmbBoot.Location = New-Object System.Drawing.Point(150,108)
$cmbBoot.Size = New-Object System.Drawing.Size(285,28)
$cmbBoot.DropDownStyle = "DropDownList"
[void]$cmbBoot.Items.Add("AUTO - DTR/RTS")
[void]$cmbBoot.Items.Add("MANUAL BOOT - USB/JTAG")
[void]$cmbBoot.Items.Add("MANUAL BOOT - UART")
$cmbBoot.SelectedIndex = 0
$form.Controls.Add($cmbBoot)

$btnBootHelp = New-Object System.Windows.Forms.Button
$btnBootHelp.Text = "Как войти в BOOT?"
$btnBootHelp.Location = New-Object System.Drawing.Point(445,107)
$btnBootHelp.Size = New-Object System.Drawing.Size(150,31)
$form.Controls.Add($btnBootHelp)

Add-Label "Адрес:" 610 112 | Out-Null
$txtAddr = New-Object System.Windows.Forms.TextBox
$txtAddr.Text = "0x0"
$txtAddr.Location = New-Object System.Drawing.Point(665,108)
$txtAddr.Size = New-Object System.Drawing.Size(85,28)
$form.Controls.Add($txtAddr)

Add-Label "Python:" 20 153 | Out-Null
$txtPython = New-Object System.Windows.Forms.TextBox
$txtPython.Text = "python"
$txtPython.Location = New-Object System.Drawing.Point(85,149)
$txtPython.Size = New-Object System.Drawing.Size(190,28)
$form.Controls.Add($txtPython)

$statusLabel = Add-Label "Готов." 300 153 450
$statusLabel.ForeColor = [System.Drawing.Color]::FromArgb(80,160,80)

Add-Label "Команда:" 20 194 | Out-Null
$txtCmd = New-Object System.Windows.Forms.TextBox
$txtCmd.Location = New-Object System.Drawing.Point(20,219)
$txtCmd.Size = New-Object System.Drawing.Size(730,58)
$txtCmd.Multiline = $true
$txtCmd.ReadOnly = $true
$txtCmd.BackColor = [System.Drawing.Color]::White
$form.Controls.Add($txtCmd)

$btnTest = New-Object System.Windows.Forms.Button
$btnTest.Text = "ПРОВЕРИТЬ СВЯЗЬ"
$btnTest.Location = New-Object System.Drawing.Point(20,292)
$btnTest.Size = New-Object System.Drawing.Size(175,42)
$form.Controls.Add($btnTest)

$btnFlash = New-Object System.Windows.Forms.Button
$btnFlash.Text = "ПРОШИТЬ"
$btnFlash.Location = New-Object System.Drawing.Point(205,292)
$btnFlash.Size = New-Object System.Drawing.Size(150,42)
$btnFlash.BackColor = [System.Drawing.Color]::FromArgb(0,120,215)
$btnFlash.ForeColor = [System.Drawing.Color]::White
$btnFlash.FlatStyle = "Flat"
$form.Controls.Add($btnFlash)

$btnStop = New-Object System.Windows.Forms.Button
$btnStop.Text = "STOP"
$btnStop.Location = New-Object System.Drawing.Point(365,292)
$btnStop.Size = New-Object System.Drawing.Size(100,42)
$btnStop.Enabled = $false
$form.Controls.Add($btnStop)

$btnInstall = New-Object System.Windows.Forms.Button
$btnInstall.Text = "Обновить esptool"
$btnInstall.Location = New-Object System.Drawing.Point(475,292)
$btnInstall.Size = New-Object System.Drawing.Size(145,42)
$form.Controls.Add($btnInstall)

$progress = New-Object System.Windows.Forms.ProgressBar
$progress.Location = New-Object System.Drawing.Point(630,301)
$progress.Size = New-Object System.Drawing.Size(120,24)
$form.Controls.Add($progress)

$txtLog = New-Object System.Windows.Forms.TextBox
$txtLog.Location = New-Object System.Drawing.Point(20,350)
$txtLog.Size = New-Object System.Drawing.Size(730,235)
$txtLog.Multiline = $true
$txtLog.ScrollBars = "Vertical"
$txtLog.ReadOnly = $true
$txtLog.BackColor = [System.Drawing.Color]::FromArgb(20,20,20)
$txtLog.ForeColor = [System.Drawing.Color]::Gainsboro
$txtLog.Font = New-Object System.Drawing.Font("Consolas",9)
$form.Controls.Add($txtLog)

function Refresh-Ports {
    $old = $cmbPort.SelectedItem
    $cmbPort.Items.Clear()
    $ports = [System.IO.Ports.SerialPort]::GetPortNames() | Sort-Object {
        if ($_ -match 'COM(\d+)') { [int]$Matches[1] } else { 9999 }
    }
    foreach ($p in $ports) { [void]$cmbPort.Items.Add($p) }
    if ($old -and $cmbPort.Items.Contains($old)) {
        $cmbPort.SelectedItem = $old
    } elseif ($cmbPort.Items.Count -gt 0) {
        $cmbPort.SelectedIndex = 0
    }
    Update-Command
}

function Get-ResetOptions {
    $mode = $cmbBoot.SelectedItem.ToString()
    if ($mode -eq "MANUAL BOOT - USB/JTAG") {
        return @("no-reset","watchdog-reset")
    }
    if ($mode -eq "MANUAL BOOT - UART") {
        return @("no-reset","hard-reset")
    }
    return @("default-reset","hard-reset")
}

function Build-EsptoolCommand([string]$operation) {
    $py = $txtPython.Text.Trim()
    if (-not $py) { $py = "python" }
    $port = if ($cmbPort.SelectedItem) { $cmbPort.SelectedItem.ToString() } else { "<COM>" }
    $chip = $cmbChip.SelectedItem.ToString()
    $baud = $cmbBaud.SelectedItem.ToString()
    $reset = Get-ResetOptions
    $before = $reset[0]
    $after = $reset[1]

    if ($operation -eq "test") {
        return "$py -m esptool --chip $chip --port $port --before $before --after $after flash-id"
    }

    $bin = $txtBin.Text.Trim()
    if (-not $bin) { $bin = "<firmware.bin>" }
    $addr = $txtAddr.Text.Trim()
    if (-not $addr) { $addr = "0x0" }
    return "$py -m esptool --chip $chip --port $port --baud $baud --before $before --after $after write-flash $addr `"$bin`""
}

function Update-Command {
    $txtCmd.Text = Build-EsptoolCommand "flash"
}

function Set-Busy([bool]$busy) {
    $btnFlash.Enabled = -not $busy
    $btnTest.Enabled = -not $busy
    $btnBrowse.Enabled = -not $busy
    $btnRefresh.Enabled = -not $busy
    $btnInstall.Enabled = -not $busy
    $cmbPort.Enabled = -not $busy
    $cmbChip.Enabled = -not $busy
    $cmbBaud.Enabled = -not $busy
    $cmbBoot.Enabled = -not $busy
    $btnStop.Enabled = $busy
    if ($busy) { $progress.Style = "Marquee" }
    else { $progress.Style = "Blocks" }
}

function Validate-Port {
    if (-not $cmbPort.SelectedItem) {
        [System.Windows.Forms.MessageBox]::Show(
            "COM порт не выбран. Подключите плату и нажмите Обновить.",
            "ESP32 BIN Flasher v2","OK","Warning"
        ) | Out-Null
        return $false
    }
    return $true
}

function Start-Tool([string]$operation) {
    if ($script:proc -and -not $script:proc.HasExited) { return }
    if (-not (Validate-Port)) { return }

    if ($operation -eq "flash") {
        $bin = $txtBin.Text.Trim()
        if (-not (Test-Path -LiteralPath $bin -PathType Leaf)) {
            [System.Windows.Forms.MessageBox]::Show(
                "Выберите существующий BIN файл.",
                "ESP32 BIN Flasher v2","OK","Warning"
            ) | Out-Null
            return
        }
    }

    $command = Build-EsptoolCommand $operation

    try { Remove-Item -LiteralPath $script:logFile -Force -ErrorAction SilentlyContinue } catch {}
    try { Remove-Item -LiteralPath $script:cmdFile -Force -ErrorAction SilentlyContinue } catch {}

    $safeLog = $script:logFile.Replace('"','')
    $cmdText = "@echo off`r`n"
    $cmdText += "set ESPTOOL_OPEN_PORT_ATTEMPTS=1`r`n"
    $cmdText += "$command > `"$safeLog`" 2>&1`r`n"
    $cmdText += "exit /b %errorlevel%`r`n"
    [System.IO.File]::WriteAllText($script:cmdFile, $cmdText, [System.Text.Encoding]::ASCII)

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $env:ComSpec
    $psi.Arguments = "/d /c `"$script:cmdFile`""
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true

    $p = New-Object System.Diagnostics.Process
    $p.StartInfo = $psi

    try {
        [void]$p.Start()
    } catch {
        [System.Windows.Forms.MessageBox]::Show(
            "Не удалось запустить esptool:`r`n$($_.Exception.Message)",
            "ESP32 BIN Flasher v2","OK","Error"
        ) | Out-Null
        return
    }

    $script:proc = $p
    $script:operation = $operation
    $script:lastLog = ""
    $txtLog.Clear()
    $txtLog.AppendText(">>> $command`r`n`r`n")
    $statusLabel.Text = if ($operation -eq "flash") { "Прошивка..." } else { "Проверка связи..." }
    $statusLabel.ForeColor = [System.Drawing.Color]::DarkOrange
    Set-Busy $true
    $timer.Start()
}

function Show-ManualBootHelp {
    $text = @"
Если AUTO не переводит плату в загрузчик:

1. Зажмите кнопку BOOT.
2. Нажмите и отпустите RESET / RST / EN.
3. Отпустите BOOT.
4. В программе выберите:
   MANUAL BOOT - USB/JTAG
5. Нажмите ПРОВЕРИТЬ СВЯЗЬ.
6. Если ESP32-S3 определяется - нажмите ПРОШИТЬ.

Если отдельной RESET-кнопки нет:
зажмите BOOT, переподключите USB, затем отпустите BOOT.

AUTO работает только когда DTR/RTS аппаратно соединены
с GPIO0 и EN через схему автосброса.
"@
    [System.Windows.Forms.MessageBox]::Show(
        $text,"Вход ESP32-S3 в BOOT","OK","Information"
    ) | Out-Null
}

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 200
$timer.Add_Tick({
    if (Test-Path -LiteralPath $script:logFile) {
        try {
            $content = [System.IO.File]::ReadAllText($script:logFile)
            if ($content -ne $script:lastLog) {
                $script:lastLog = $content
                $first = $txtLog.Text.Split([Environment]::NewLine)[0]
                $txtLog.Text = $first + "`r`n`r`n" + $content
                $txtLog.SelectionStart = $txtLog.Text.Length
                $txtLog.ScrollToCaret()
            }
        } catch {}
    }

    if ($script:proc -and $script:proc.HasExited) {
        $timer.Stop()
        $exitCode = $script:proc.ExitCode
        $op = $script:operation
        Set-Busy $false

        if ($exitCode -eq 0) {
            $progress.Value = 100
            if ($op -eq "flash") {
                $statusLabel.Text = "Готово - прошивка записана."
                [System.Windows.Forms.MessageBox]::Show(
                    "Прошивка записана успешно.",
                    "ESP32 BIN Flasher v2","OK","Information"
                ) | Out-Null
            } else {
                $statusLabel.Text = "Связь с ESP32 установлена."
                [System.Windows.Forms.MessageBox]::Show(
                    "ESP32 отвечает. Можно прошивать.",
                    "ESP32 BIN Flasher v2","OK","Information"
                ) | Out-Null
            }
            $statusLabel.ForeColor = [System.Drawing.Color]::ForestGreen
        } else {
            $progress.Value = 0
            $statusLabel.Text = "Ошибка подключения / прошивки."
            $statusLabel.ForeColor = [System.Drawing.Color]::Firebrick

            if ($cmbBoot.SelectedItem.ToString() -eq "AUTO - DTR/RTS") {
                $r = [System.Windows.Forms.MessageBox]::Show(
                    "AUTO не сработал.`r`n`r`nПоказать порядок ручного входа BOOT?",
                    "ESP32 BIN Flasher v2","YesNo","Warning"
                )
                if ($r -eq "Yes") { Show-ManualBootHelp }
            }
        }

        $script:proc.Dispose()
        $script:proc = $null
    }
})

$btnBrowse.Add_Click({
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Filter = "BIN firmware (*.bin)|*.bin|All files (*.*)|*.*"
    $dlg.Title = "Выберите BIN для ESP32"
    if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $txtBin.Text = $dlg.FileName
        Update-Command
    }
})

$btnRefresh.Add_Click({ Refresh-Ports })
$btnBootHelp.Add_Click({ Show-ManualBootHelp })
$btnTest.Add_Click({ Start-Tool "test" })
$btnFlash.Add_Click({ Start-Tool "flash" })

$btnStop.Add_Click({
    if ($script:proc -and -not $script:proc.HasExited) {
        try {
            $pidToKill = $script:proc.Id
            Start-Process -FilePath "taskkill.exe" -ArgumentList "/PID $pidToKill /T /F" -WindowStyle Hidden -Wait
        } catch {
            try { $script:proc.Kill() } catch {}
        }
        $statusLabel.Text = "Остановлено пользователем."
        $statusLabel.ForeColor = [System.Drawing.Color]::Firebrick
    }
})

$btnInstall.Add_Click({
    if ($script:proc -and -not $script:proc.HasExited) { return }
    $py = $txtPython.Text.Trim()
    if (-not $py) { $py = "python" }

    $command = "$py -m pip install --upgrade esptool"
    try { Remove-Item -LiteralPath $script:logFile -Force -ErrorAction SilentlyContinue } catch {}
    $safeLog = $script:logFile.Replace('"','')
    $cmdText = "@echo off`r`n$command > `"$safeLog`" 2>&1`r`nexit /b %errorlevel%`r`n"
    [System.IO.File]::WriteAllText($script:cmdFile, $cmdText, [System.Text.Encoding]::ASCII)

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $env:ComSpec
    $psi.Arguments = "/d /c `"$script:cmdFile`""
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $p = New-Object System.Diagnostics.Process
    $p.StartInfo = $psi

    try { [void]$p.Start() }
    catch {
        [System.Windows.Forms.MessageBox]::Show(
            "Не удалось запустить Python.",
            "ESP32 BIN Flasher v2","OK","Error"
        ) | Out-Null
        return
    }

    $script:proc = $p
    $script:operation = "install"
    $script:lastLog = ""
    $txtLog.Clear()
    $txtLog.AppendText(">>> $command`r`n`r`n")
    $statusLabel.Text = "Обновление esptool..."
    $statusLabel.ForeColor = [System.Drawing.Color]::DarkOrange
    Set-Busy $true
    $timer.Start()
})

$txtBin.Add_TextChanged({ Update-Command })
$txtAddr.Add_TextChanged({ Update-Command })
$txtPython.Add_TextChanged({ Update-Command })
$cmbPort.Add_SelectedIndexChanged({ Update-Command })
$cmbChip.Add_SelectedIndexChanged({ Update-Command })
$cmbBaud.Add_SelectedIndexChanged({ Update-Command })
$cmbBoot.Add_SelectedIndexChanged({ Update-Command })

$form.Add_FormClosing({
    if ($script:proc -and -not $script:proc.HasExited) {
        try {
            $pidToKill = $script:proc.Id
            Start-Process -FilePath "taskkill.exe" -ArgumentList "/PID $pidToKill /T /F" -WindowStyle Hidden -Wait
        } catch {}
    }
    try { Remove-Item -LiteralPath $script:cmdFile -Force -ErrorAction SilentlyContinue } catch {}
    try { Remove-Item -LiteralPath $script:logFile -Force -ErrorAction SilentlyContinue } catch {}
})

$form.Add_Shown({
    Refresh-Ports
    Update-Command
})

[void]$form.ShowDialog()
