MA01-XXCX0080 8DO Modbus RTU GUI v0.5.1
============================================================

What changed from v0.5.0
------------------------
- Slave ID is NOT hard-coded to 32 or any other address.
- On first start the Slave ID field is empty.
- The user can enter 1..247 manually, or use Search device.
- A discovered or manually used valid Slave ID is saved to:
  %APPDATA%\AIDevelopersMonster\MA01-XXCX0080\config.json
- Search device probes the selected address range and, when the MA01 responds
  at model/firmware registers 0x07D0 and 0x07DC, makes that address current.
- No background polling. Reads happen only on explicit user actions and the
  one delayed readback after a PULSE trigger.
- Full TX/RX hex log remains visible.

Physical module used in the current lab
---------------------------------------
- MA01-XXCX0080
- firmware V1.6
- current discovered slave address: 16
- 9600 8N1

Important
---------
Slave address is device configuration. It is not a firmware/client constant.
Earlier lab sessions used address 32; that is historical configuration only.

Registers
---------
Coils 0x0000..0x0007  DO1..DO8
Holding 0x0578..0x057F mode (0 LEVEL, 1 PULSE, 2 FOLLOW)
Holding 0x05DC..0x05E3 pulse width, ms
Holding 0x07D0 model
Holding 0x07DC firmware

Run
---
Double-click run_MA01_8DO_GUI.bat
or:
  python MA01_8DO_GUI.py

Requires Python 3 and pyserial. Tkinter is included in the normal Windows
Python installer.
