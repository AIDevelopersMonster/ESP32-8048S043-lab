@echo off
setlocal
python -m pip show pyserial >nul 2>&1 || python -m pip install pyserial
python "%~dp0MA01_8DO_GUI.py"
endlocal
