#!/usr/bin/env python3
import json
import os
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, ttk

import serial
from serial.tools import list_ports

APP_VERSION = "0.5.1"
PRODUCT_NAME = "Ebyte MA01-XXCX0080"
MODE_NAMES = {0: "LEVEL", 1: "PULSE", 2: "FOLLOW"}
MODE_VALUES = {v: k for k, v in MODE_NAMES.items()}

COIL_BASE = 0x0000
MODE_BASE = 0x0578
PULSE_BASE = 0x05DC
MODEL_REG = 0x07D0
FW_REG = 0x07DC


def crc16_modbus(data: bytes) -> int:
    crc = 0xFFFF
    for b in data:
        crc ^= b
        for _ in range(8):
            crc = (crc >> 1) ^ 0xA001 if crc & 1 else crc >> 1
    return crc & 0xFFFF


def add_crc(payload: bytes) -> bytes:
    crc = crc16_modbus(payload)
    return payload + bytes((crc & 0xFF, (crc >> 8) & 0xFF))


def config_path() -> Path:
    root = Path(os.getenv("APPDATA") or Path.home())
    return root / "AIDevelopersMonster" / "MA01-XXCX0080" / "config.json"


class Settings:
    DEFAULT = {
        "port": "",
        "baud": 9600,
        "parity": "N",
        "slave_id": None,
        "timeout": 0.5,
        "search_range": "1-32",
    }

    @classmethod
    def load(cls):
        data = dict(cls.DEFAULT)
        path = config_path()
        try:
            if path.exists():
                saved = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(saved, dict):
                    data.update(saved)
        except Exception:
            pass
        # Never invent a slave address. It must be saved, discovered, or entered by the user.
        sid = data.get("slave_id")
        if not isinstance(sid, int) or not 1 <= sid <= 247:
            data["slave_id"] = None
        return data

    @classmethod
    def save(cls, data):
        path = config_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")


class ModbusRTU:
    def __init__(self, log_cb, stats_cb):
        self.ser = None
        self.log_cb = log_cb
        self.stats_cb = stats_cb
        self.tx_frames = 0
        self.rx_frames = 0
        self.crc_errors = 0
        self.timeouts = 0
        self.protocol_errors = 0
        self.lock = threading.Lock()

    @property
    def connected(self):
        return self.ser is not None and self.ser.is_open

    def _stats(self, last_error=""):
        self.stats_cb(self.tx_frames, self.rx_frames, self.crc_errors,
                      self.timeouts, self.protocol_errors, last_error)

    def open(self, port, baud, parity, timeout):
        self.close()
        parity_map = {"N": serial.PARITY_NONE, "E": serial.PARITY_EVEN, "O": serial.PARITY_ODD}
        self.ser = serial.Serial(
            port=port,
            baudrate=baud,
            bytesize=serial.EIGHTBITS,
            parity=parity_map[parity],
            stopbits=serial.STOPBITS_ONE,
            timeout=timeout,
            write_timeout=timeout,
        )
        self.ser.reset_input_buffer()
        self.ser.reset_output_buffer()

    def close(self):
        if self.ser:
            try:
                self.ser.close()
            except Exception:
                pass
        self.ser = None

    def _exchange(self, frame: bytes, expected_min=5) -> bytes:
        if not self.connected:
            raise RuntimeError("Serial port is not connected")
        with self.lock:
            self.ser.reset_input_buffer()
            self.log_cb("TX: " + frame.hex(" ").upper())
            self.ser.write(frame)
            self.ser.flush()
            self.tx_frames += 1

            deadline = time.monotonic() + float(self.ser.timeout or 0.5)
            buf = bytearray()
            while time.monotonic() < deadline:
                waiting = self.ser.in_waiting
                chunk = self.ser.read(waiting if waiting else 1)
                if chunk:
                    buf.extend(chunk)
                    # Modbus RTU frame end: a small silent gap after at least a minimal frame.
                    time.sleep(max(0.004, 4.0 / self.ser.baudrate))
                    if not self.ser.in_waiting and len(buf) >= expected_min:
                        break

            if not buf:
                self.timeouts += 1
                self._stats("Timeout: no response")
                raise TimeoutError("Timeout: no response")

            response = bytes(buf)
            self.log_cb("RX: " + response.hex(" ").upper())
            if len(response) < 5:
                self.protocol_errors += 1
                self._stats("Short Modbus response")
                raise RuntimeError("Short Modbus response")

            got_crc = response[-2] | (response[-1] << 8)
            calc_crc = crc16_modbus(response[:-2])
            if got_crc != calc_crc:
                self.crc_errors += 1
                self._stats("CRC error")
                raise RuntimeError("CRC error")

            self.rx_frames += 1
            self._stats("")
            return response

    def fc01_read_coils(self, slave, start, count):
        req = add_crc(bytes((slave, 0x01, start >> 8, start & 0xFF, count >> 8, count & 0xFF)))
        rsp = self._exchange(req)
        if rsp[0] != slave or rsp[1] != 0x01 or rsp[2] < 1:
            self.protocol_errors += 1
            self._stats("Invalid FC01 response")
            raise RuntimeError("Invalid FC01 response")
        data = rsp[3:3 + rsp[2]]
        return [bool(data[i // 8] & (1 << (i % 8))) for i in range(count)]

    def fc03_read_holding(self, slave, start, count):
        req = add_crc(bytes((slave, 0x03, start >> 8, start & 0xFF, count >> 8, count & 0xFF)))
        rsp = self._exchange(req)
        if rsp[0] != slave or rsp[1] != 0x03 or rsp[2] != count * 2:
            self.protocol_errors += 1
            self._stats("Invalid FC03 response")
            raise RuntimeError("Invalid FC03 response")
        return [(rsp[3 + i * 2] << 8) | rsp[4 + i * 2] for i in range(count)]

    def fc05_write_coil(self, slave, coil, on):
        value = 0xFF00 if on else 0x0000
        req = add_crc(bytes((slave, 0x05, coil >> 8, coil & 0xFF, value >> 8, value & 0xFF)))
        rsp = self._exchange(req, expected_min=8)
        if rsp[:6] != req[:6]:
            self.protocol_errors += 1
            self._stats("Invalid FC05 echo")
            raise RuntimeError("Invalid FC05 echo")

    def fc06_write_register(self, slave, reg, value):
        value &= 0xFFFF
        req = add_crc(bytes((slave, 0x06, reg >> 8, reg & 0xFF, value >> 8, value & 0xFF)))
        rsp = self._exchange(req, expected_min=8)
        if rsp[:6] != req[:6]:
            self.protocol_errors += 1
            self._stats("Invalid FC06 echo")
            raise RuntimeError("Invalid FC06 echo")

    def fc0f_write_coils(self, slave, start, values):
        count = len(values)
        byte_count = (count + 7) // 8
        packed = bytearray(byte_count)
        for i, value in enumerate(values):
            if value:
                packed[i // 8] |= 1 << (i % 8)
        body = bytes((slave, 0x0F, start >> 8, start & 0xFF,
                      count >> 8, count & 0xFF, byte_count)) + bytes(packed)
        req = add_crc(body)
        rsp = self._exchange(req, expected_min=8)
        if rsp[0] != slave or rsp[1] != 0x0F:
            self.protocol_errors += 1
            self._stats("Invalid FC0F response")
            raise RuntimeError("Invalid FC0F response")


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"{PRODUCT_NAME} 8DO — Modbus RTU GUI v{APP_VERSION}")
        self.geometry("1000x760")
        self.minsize(940, 680)

        self.cfg = Settings.load()
        self.bus = ModbusRTU(self.log, self.update_stats)
        self.coils = [None] * 8
        self.modes = [0] * 8
        self.pulses = [50] * 8

        self.port_var = tk.StringVar(value=self.cfg.get("port", ""))
        self.baud_var = tk.StringVar(value=str(self.cfg.get("baud", 9600)))
        self.parity_var = tk.StringVar(value=str(self.cfg.get("parity", "N")))
        sid = self.cfg.get("slave_id")
        self.slave_var = tk.StringVar(value=str(sid) if sid else "")
        self.timeout_var = tk.StringVar(value=str(self.cfg.get("timeout", 0.5)))
        self.search_var = tk.StringVar(value=str(self.cfg.get("search_range", "1-32")))
        self.bus_var = tk.StringVar(value="DISCONNECTED")
        self.found_var = tk.StringVar(value="Slave not selected — use Search device or enter Slave ID")
        self.last_error_var = tk.StringVar(value="")

        self.tx_var = tk.StringVar(value="0")
        self.rx_var = tk.StringVar(value="0")
        self.crc_var = tk.StringVar(value="0")
        self.timeout_count_var = tk.StringVar(value="0")
        self.proto_var = tk.StringVar(value="0")

        self._build()
        self.refresh_ports()
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    def _build(self):
        title = ttk.Label(self, text=f"{PRODUCT_NAME} — 8DO Modbus RTU", font=("Segoe UI", 18, "bold"))
        title.pack(anchor="w", padx=16, pady=(12, 4))

        conn = ttk.LabelFrame(self, text="Connection")
        conn.pack(fill="x", padx=16, pady=6)

        row = ttk.Frame(conn)
        row.pack(fill="x", padx=8, pady=8)
        ttk.Label(row, text="COM").grid(row=0, column=0, sticky="w")
        self.port_box = ttk.Combobox(row, textvariable=self.port_var, width=14, state="readonly")
        self.port_box.grid(row=0, column=1, padx=(4, 8))
        ttk.Button(row, text="Refresh ports", command=self.refresh_ports).grid(row=0, column=2, padx=(0, 16))

        ttk.Label(row, text="Baud").grid(row=0, column=3)
        ttk.Combobox(row, textvariable=self.baud_var, width=8, values=("9600", "19200", "38400", "57600", "115200"), state="readonly").grid(row=0, column=4, padx=4)
        ttk.Label(row, text="Parity").grid(row=0, column=5, padx=(8, 0))
        ttk.Combobox(row, textvariable=self.parity_var, width=4, values=("N", "E", "O"), state="readonly").grid(row=0, column=6, padx=4)
        ttk.Label(row, text="Slave ID").grid(row=0, column=7, padx=(8, 0))
        ttk.Entry(row, textvariable=self.slave_var, width=7).grid(row=0, column=8, padx=4)
        ttk.Label(row, text="Timeout s").grid(row=0, column=9, padx=(8, 0))
        ttk.Entry(row, textvariable=self.timeout_var, width=6).grid(row=0, column=10, padx=4)

        row2 = ttk.Frame(conn)
        row2.pack(fill="x", padx=8, pady=(0, 8))
        self.connect_btn = ttk.Button(row2, text="Connect", command=self.toggle_connect)
        self.connect_btn.pack(side="left")
        ttk.Button(row2, text="READ STATUS DO1..DO8", command=self.read_status).pack(side="left", padx=6)
        ttk.Button(row2, text="ALL ON", command=lambda: self.write_all(True)).pack(side="left", padx=2)
        ttk.Button(row2, text="ALL OFF", command=lambda: self.write_all(False)).pack(side="left", padx=2)

        ttk.Label(row2, text="Search range").pack(side="left", padx=(18, 4))
        ttk.Combobox(row2, textvariable=self.search_var, width=9, values=("1-32", "1-64", "1-247")).pack(side="left")
        ttk.Button(row2, text="Search device", command=self.search_device).pack(side="left", padx=6)
        ttk.Label(row2, text="Bus:").pack(side="left", padx=(18, 4))
        ttk.Label(row2, textvariable=self.bus_var, width=14).pack(side="left")

        ttk.Label(conn, textvariable=self.found_var).pack(anchor="w", padx=8, pady=(0, 7))

        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill="both", expand=True, padx=16, pady=4)
        self.control_tab = ttk.Frame(self.tabs)
        self.reg_tab = ttk.Frame(self.tabs)
        self.mode_tab = ttk.Frame(self.tabs)
        self.tabs.add(self.control_tab, text="1. CONTROL")
        self.tabs.add(self.reg_tab, text="2. REGISTER LAB")
        self.tabs.add(self.mode_tab, text="3. MODE SETUP")
        self._build_control()
        self._build_register_lab()
        self._build_mode_setup()

        diag = ttk.LabelFrame(self, text="Diagnostics")
        diag.pack(fill="x", padx=16, pady=6)
        drow = ttk.Frame(diag)
        drow.pack(fill="x", padx=8, pady=6)
        for label, var in (("TX frames", self.tx_var), ("RX frames", self.rx_var),
                           ("CRC errors", self.crc_var), ("Timeouts", self.timeout_count_var),
                           ("Protocol errors", self.proto_var)):
            box = ttk.Frame(drow)
            box.pack(side="left", padx=(0, 28))
            ttk.Label(box, text=label).pack(anchor="w")
            ttk.Label(box, textvariable=var, font=("Segoe UI", 10, "bold")).pack(anchor="w")
        ttk.Label(diag, text="Last error:").pack(side="left", padx=(8, 4), pady=(0, 6))
        ttk.Label(diag, textvariable=self.last_error_var).pack(side="left", pady=(0, 6))

        logbox = ttk.LabelFrame(self, text="Modbus RTU log")
        logbox.pack(fill="both", expand=False, padx=16, pady=(0, 12))
        top = ttk.Frame(logbox)
        top.pack(fill="x")
        ttk.Button(top, text="Clear log", command=lambda: self.log_text.delete("1.0", "end")).pack(side="right", padx=6, pady=4)
        self.log_text = tk.Text(logbox, height=8, wrap="none", font=("Consolas", 9))
        self.log_text.pack(fill="both", expand=True, padx=6, pady=(0, 6))

    def _build_control(self):
        frame = ttk.LabelFrame(self.control_tab, text="Relay outputs DO1..DO8")
        frame.pack(fill="both", expand=True, padx=10, pady=10)
        self.state_vars = []
        self.mode_label_vars = []
        self.do_buttons = []
        for i in range(8):
            card = ttk.LabelFrame(frame, text=f"DO{i+1}")
            card.grid(row=0, column=i, padx=4, pady=8, sticky="nsew")
            frame.columnconfigure(i, weight=1)
            state = tk.StringVar(value="UNKNOWN")
            mode = tk.StringVar(value="MODE: ?")
            self.state_vars.append(state)
            self.mode_label_vars.append(mode)
            btn = ttk.Button(card, textvariable=state, command=lambda ch=i: self.toggle_channel(ch))
            btn.pack(fill="x", padx=6, pady=(8, 4))
            self.do_buttons.append(btn)
            ttk.Label(card, textvariable=mode).pack(padx=6, pady=(4, 8))

    def _build_register_lab(self):
        read = ttk.LabelFrame(self.reg_tab, text="Holding register FC03 / FC06")
        read.pack(fill="x", padx=10, pady=10)
        self.reg_addr_var = tk.StringVar(value="0x07D0")
        self.reg_count_var = tk.StringVar(value="1")
        self.reg_write_var = tk.StringVar(value="0")
        ttk.Label(read, text="Address").grid(row=0, column=0, padx=4, pady=6)
        ttk.Entry(read, textvariable=self.reg_addr_var, width=12).grid(row=0, column=1, padx=4)
        ttk.Label(read, text="Count").grid(row=0, column=2, padx=4)
        ttk.Entry(read, textvariable=self.reg_count_var, width=8).grid(row=0, column=3, padx=4)
        ttk.Button(read, text="READ FC03", command=self.reg_read).grid(row=0, column=4, padx=8)
        ttk.Label(read, text="Write value").grid(row=0, column=5, padx=4)
        ttk.Entry(read, textvariable=self.reg_write_var, width=12).grid(row=0, column=6, padx=4)
        ttk.Button(read, text="WRITE FC06", command=self.reg_write).grid(row=0, column=7, padx=8)
        self.reg_result = tk.Text(read, height=7, font=("Consolas", 9))
        self.reg_result.grid(row=1, column=0, columnspan=8, sticky="ew", padx=6, pady=6)

        coils = ttk.LabelFrame(self.reg_tab, text="Coil mask FC01 / FC0F")
        coils.pack(fill="x", padx=10, pady=10)
        self.mask_vars = [tk.BooleanVar(value=False) for _ in range(8)]
        for i, var in enumerate(self.mask_vars):
            ttk.Checkbutton(coils, text=f"DO{i+1}", variable=var).grid(row=0, column=i, padx=8, pady=8)
        ttk.Button(coils, text="READ FC01", command=self.mask_read).grid(row=1, column=0, columnspan=4, padx=6, pady=6, sticky="ew")
        ttk.Button(coils, text="WRITE FC0F", command=self.mask_write).grid(row=1, column=4, columnspan=4, padx=6, pady=6, sticky="ew")

    def _build_mode_setup(self):
        top = ttk.Frame(self.mode_tab)
        top.pack(fill="x", padx=10, pady=(10, 0))
        ttk.Button(top, text="READ MODE CONFIG", command=self.read_mode_config).pack(side="left")
        ttk.Button(top, text="APPLY ALL 8", command=self.apply_all_modes).pack(side="left", padx=6)

        grid = ttk.Frame(self.mode_tab)
        grid.pack(fill="both", expand=True, padx=10, pady=10)
        self.mode_vars = []
        self.pulse_vars = []
        for i in range(8):
            card = ttk.LabelFrame(grid, text=f"DO{i+1}")
            card.grid(row=i // 4, column=i % 4, padx=6, pady=6, sticky="nsew")
            grid.columnconfigure(i % 4, weight=1)
            mv = tk.StringVar(value="LEVEL")
            pv = tk.StringVar(value="50")
            self.mode_vars.append(mv)
            self.pulse_vars.append(pv)
            ttk.Label(card, text="Mode").pack(anchor="w", padx=8, pady=(8, 2))
            ttk.Combobox(card, textvariable=mv, values=("LEVEL", "PULSE", "FOLLOW"), state="readonly").pack(fill="x", padx=8)
            ttk.Label(card, text="Pulse width ms").pack(anchor="w", padx=8, pady=(8, 2))
            ttk.Entry(card, textvariable=pv).pack(fill="x", padx=8)
            ttk.Button(card, text="APPLY", command=lambda ch=i: self.apply_mode(ch)).pack(fill="x", padx=8, pady=8)

    def log(self, message):
        def emit():
            stamp = time.strftime("%H:%M:%S") + f".{int((time.time() % 1) * 1000):03d}"
            self.log_text.insert("end", f"{stamp} {message}\n")
            self.log_text.see("end")
        if threading.current_thread() is threading.main_thread():
            emit()
        else:
            self.after(0, emit)

    def update_stats(self, tx, rx, crc, timeouts, proto, last_error):
        def do():
            self.tx_var.set(str(tx)); self.rx_var.set(str(rx)); self.crc_var.set(str(crc))
            self.timeout_count_var.set(str(timeouts)); self.proto_var.set(str(proto))
            self.last_error_var.set(last_error)
        if threading.current_thread() is threading.main_thread():
            do()
        else:
            self.after(0, do)

    def refresh_ports(self):
        ports = [p.device for p in list_ports.comports()]
        self.port_box["values"] = ports
        if self.port_var.get() not in ports:
            if self.cfg.get("port") in ports:
                self.port_var.set(self.cfg["port"])
            elif ports:
                self.port_var.set(ports[0])

    def _slave(self):
        text = self.slave_var.get().strip()
        if not text:
            raise ValueError("Slave ID is not set. Use Search device or enter 1..247.")
        sid = int(text, 0)
        if not 1 <= sid <= 247:
            raise ValueError("Slave ID must be 1..247")
        return sid

    def _serial_params(self):
        port = self.port_var.get().strip()
        if not port:
            raise ValueError("Select COM port")
        return port, int(self.baud_var.get()), self.parity_var.get(), float(self.timeout_var.get())

    def save_settings(self):
        sid = None
        try:
            sid = self._slave()
        except Exception:
            pass
        data = {
            "port": self.port_var.get().strip(),
            "baud": int(self.baud_var.get()),
            "parity": self.parity_var.get(),
            "slave_id": sid,
            "timeout": float(self.timeout_var.get()),
            "search_range": self.search_var.get().strip(),
        }
        try:
            Settings.save(data)
        except Exception as exc:
            self.log(f"Config save warning: {exc}")

    def toggle_connect(self):
        if self.bus.connected:
            self.bus.close()
            self.bus_var.set("DISCONNECTED")
            self.connect_btn.config(text="Connect")
            return
        try:
            sid = self._slave()
            port, baud, parity, timeout = self._serial_params()
            self.bus.open(port, baud, parity, timeout)
            self.bus_var.set("CONNECTED")
            self.connect_btn.config(text="Disconnect")
            self.found_var.set(f"Current slave: {sid} | {PRODUCT_NAME}")
            self.log(f"Connected: {port}, slave={sid}, {baud} 8{parity}1, timeout={timeout}s")
            self.save_settings()
        except Exception as exc:
            self.bus.close()
            self.bus_var.set("DISCONNECTED")
            messagebox.showerror("Connection", str(exc))

    def _with_temp_bus(self):
        port, baud, parity, timeout = self._serial_params()
        temp = ModbusRTU(self.log, self.update_stats)
        temp.open(port, baud, parity, timeout)
        return temp

    def search_device(self):
        if self.bus.connected:
            messagebox.showinfo("Search device", "Disconnect first, then run discovery.")
            return
        try:
            a, b = self.search_var.get().strip().split("-", 1)
            start, end = int(a), int(b)
            if not (1 <= start <= end <= 247):
                raise ValueError
        except Exception:
            messagebox.showerror("Search device", "Search range must be like 1-32, within 1..247")
            return

        def worker():
            temp = None
            try:
                temp = self._with_temp_bus()
                self.log(f"Search started: slaves {start}..{end}")
                for sid in range(start, end + 1):
                    try:
                        model = temp.fc03_read_holding(sid, MODEL_REG, 1)[0]
                        fw = temp.fc03_read_holding(sid, FW_REG, 1)[0]
                    except Exception:
                        continue
                    self.after(0, lambda s=sid, m=model, f=fw: self._device_found(s, m, f))
                    return
                self.after(0, lambda: self.found_var.set("No MA01 response in selected search range"))
            except Exception as exc:
                self.after(0, lambda e=str(exc): messagebox.showerror("Search device", e))
            finally:
                if temp:
                    temp.close()
        threading.Thread(target=worker, daemon=True).start()

    def _device_found(self, sid, model, fw):
        self.slave_var.set(str(sid))
        self.found_var.set(f"Found: Slave {sid} | {PRODUCT_NAME} | model=0x{model:04X} fw=0x{fw:04X}")
        self.log(f"FOUND slave={sid}: model=0x{model:04X}, firmware=0x{fw:04X}")
        self.save_settings()

    def _require_connected(self):
        if not self.bus.connected:
            raise RuntimeError("Connect to the device first")
        return self._slave()

    def read_status(self):
        try:
            sid = self._require_connected()
            vals = self.bus.fc01_read_coils(sid, COIL_BASE, 8)
            self.coils = vals
            for i, v in enumerate(vals):
                self.state_vars[i].set("ON" if v else "OFF")
                self.mask_vars[i].set(v)
        except Exception as exc:
            self.last_error_var.set(str(exc))
            self.log(f"Read error: {exc}")

    def toggle_channel(self, ch):
        try:
            sid = self._require_connected()
            mode = self.modes[ch]
            if mode == 2:
                messagebox.showinfo("FOLLOW", "Direct control is disabled in FOLLOW mode")
                return
            if mode == 1:
                self.bus.fc05_write_coil(sid, COIL_BASE + ch, True)
                self.state_vars[ch].set("TRIGGERED")
                delay = max(50, min(60000, int(self.pulses[ch]))) + 100
                self.after(delay, self.read_status)
                return
            current = self.coils[ch]
            if current is None:
                self.read_status()
                current = self.coils[ch]
                if current is None:
                    return
            self.bus.fc05_write_coil(sid, COIL_BASE + ch, not current)
            self.read_status()
        except Exception as exc:
            self.last_error_var.set(str(exc))
            self.log(f"Control error: {exc}")

    def write_all(self, on):
        try:
            sid = self._require_connected()
            self.bus.fc0f_write_coils(sid, COIL_BASE, [on] * 8)
            self.read_status()
        except Exception as exc:
            self.last_error_var.set(str(exc)); self.log(f"Write error: {exc}")

    def reg_read(self):
        try:
            sid = self._require_connected()
            addr = int(self.reg_addr_var.get(), 0)
            count = int(self.reg_count_var.get(), 0)
            vals = self.bus.fc03_read_holding(sid, addr, count)
            self.reg_result.delete("1.0", "end")
            for i, v in enumerate(vals):
                self.reg_result.insert("end", f"0x{addr+i:04X}: 0x{v:04X}  {v:5d}  {v:016b}\n")
        except Exception as exc:
            self.last_error_var.set(str(exc)); self.log(f"Register read error: {exc}")

    def reg_write(self):
        try:
            sid = self._require_connected()
            addr = int(self.reg_addr_var.get(), 0)
            value = int(self.reg_write_var.get(), 0)
            self.bus.fc06_write_register(sid, addr, value)
            self.log(f"FC06 OK: 0x{addr:04X} = 0x{value & 0xFFFF:04X}")
        except Exception as exc:
            self.last_error_var.set(str(exc)); self.log(f"Register write error: {exc}")

    def mask_read(self):
        self.read_status()

    def mask_write(self):
        try:
            sid = self._require_connected()
            vals = [v.get() for v in self.mask_vars]
            self.bus.fc0f_write_coils(sid, COIL_BASE, vals)
            self.read_status()
        except Exception as exc:
            self.last_error_var.set(str(exc)); self.log(f"Coil mask write error: {exc}")

    def read_mode_config(self):
        try:
            sid = self._require_connected()
            modes = self.bus.fc03_read_holding(sid, MODE_BASE, 8)
            pulses = self.bus.fc03_read_holding(sid, PULSE_BASE, 8)
            self.modes = modes[:]
            self.pulses = pulses[:]
            for i in range(8):
                name = MODE_NAMES.get(modes[i], f"UNKNOWN({modes[i]})")
                self.mode_vars[i].set(name if name in MODE_VALUES else "LEVEL")
                self.pulse_vars[i].set(str(pulses[i]))
                if modes[i] == 1:
                    self.mode_label_vars[i].set(f"PULSE {pulses[i]} ms")
                else:
                    self.mode_label_vars[i].set(f"MODE: {name}")
        except Exception as exc:
            self.last_error_var.set(str(exc)); self.log(f"Mode read error: {exc}")

    def apply_mode(self, ch):
        try:
            sid = self._require_connected()
            mode_name = self.mode_vars[ch].get()
            mode = MODE_VALUES[mode_name]
            pulse = int(self.pulse_vars[ch].get(), 0)
            if not 0 <= pulse <= 65535:
                raise ValueError("Pulse width must be 0..65535 ms")
            self.bus.fc06_write_register(sid, MODE_BASE + ch, mode)
            self.bus.fc06_write_register(sid, PULSE_BASE + ch, pulse)
            self.modes[ch] = mode
            self.pulses[ch] = pulse
            self.mode_label_vars[ch].set(f"PULSE {pulse} ms" if mode == 1 else f"MODE: {mode_name}")
        except Exception as exc:
            self.last_error_var.set(str(exc)); self.log(f"Mode write error: {exc}")

    def apply_all_modes(self):
        for ch in range(8):
            self.apply_mode(ch)

    def on_close(self):
        self.save_settings()
        self.bus.close()
        self.destroy()


if __name__ == "__main__":
    App().mainloop()
